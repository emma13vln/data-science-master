# Data Science - Extra Resources

## Courses

- [Statistics](#statistics)

---

### Statistics

Courses | Duration | Effort
:-- | :--: | :--:
[Intro to Statistics](https://www.udacity.com/course/intro-to-statistics--st101)| 8 weeks | 6 hours/week
[Basic Statistics](https://www.coursera.org/learn/basic-statistics)| 8 weeks | 3 hours/week
[Bayesian Statistics](https://www.coursera.org/learn/bayesian)| 5 weeks | 5-7 hours/week
